package com.tg.lms_backend;

public class UsernameNotFoundException extends RuntimeException {
public UsernameNotFoundException(String message) {
	super(message);
}
}

