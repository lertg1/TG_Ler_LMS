package com.tg.lms_backend.config;

public @interface enableWebSecurity {

}
